'use strict';
/*global describe,it,expect:false */
var sc = require('spatialconnect-js');

describe('Feature',function () {
  it('Create',function(done){
    var fObj =
    sc.action.createFeature(fObj);
  });

  it('Read',function (done) {

  });

  it('Update', function (done) {

  });

  it('Delete', function (done) {

  });
});
