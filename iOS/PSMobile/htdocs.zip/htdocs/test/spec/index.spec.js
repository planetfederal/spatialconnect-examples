var filter = require('./FilterSpec');
var gps = require('./GPSSpec');
var stores = require('./StoresSpec');
var feature = require('./FeatureSpec');
