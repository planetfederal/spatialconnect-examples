'use strict';
/*global describe,it,expect:false */
var sc = require('spatialconnect-js');

describe('Spatial Query',function () {
  it('Random Store',function(done){

  });

  it('All Stores',function (done) {

  });
});

describe('Geospatial Query', function () {
  it('Random Store Disjoint', function (done) {

  });

  it('All Stores Disjoint', function (done) {

  });

  it('Random Store Within', function (done) {

  });

  it('All Stores Within', function (done) {

  });
});
